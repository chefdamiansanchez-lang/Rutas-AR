package com.rutasar.mapa

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.DelayedMapListener
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.floor

class MainActivity : AppCompatActivity() {

    private data class Seg(val ref: String, val name: String, val pts: List<GeoPoint>)

    private val UA = "RutasAR/1.0 (Android app personal)"
    private val roadsExec = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()

    private lateinit var map: MapView
    private lateinit var locOverlay: MyLocationNewOverlay
    private lateinit var etOrigin: EditText
    private lateinit var etDest: EditText
    private lateinit var status: TextView

    private val loaded = LinkedHashMap<String, List<Polyline>>()
    private val pending = HashSet<String>()
    private var polyCount = 0

    private var routeLine: Polyline? = null
    private var routePoints: List<GeoPoint> = emptyList()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.any { it }) {
                locOverlay.enableMyLocation()
                goToMe()
            } else {
                toast("Sin permiso de ubicación")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        cfg.userAgentValue = UA
        val base = File(filesDir, "osmdroid")
        val tiles = File(base, "tiles")
        tiles.mkdirs()
        cfg.osmdroidBasePath = base
        cfg.osmdroidTileCache = tiles
        cfg.tileFileSystemCacheMaxBytes = 800L * 1024 * 1024
        cfg.tileFileSystemCacheTrimBytes = 700L * 1024 * 1024
        File(filesDir, "routes").mkdirs()

        buildUi()

        map.post {
            loadRoutesForView()
            restoreLastRoute()
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)

        map = MapView(this)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.minZoomLevel = 4.0
        map.maxZoomLevel = 17.0
        map.setScrollableAreaLimitDouble(BoundingBox(-20.0, -52.0, -56.5, -75.0))
        map.controller.setZoom(5.0)
        map.controller.setCenter(GeoPoint(-38.4, -63.6))
        map.overlays.add(CopyrightOverlay(this))
        locOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        map.overlays.add(locOverlay)
        map.addMapListener(DelayedMapListener(object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean {
                loadRoutesForView()
                return false
            }

            override fun onZoom(event: ZoomEvent?): Boolean {
                loadRoutesForView()
                return false
            }
        }, 700))
        root.addView(map, FrameLayout.LayoutParams(match, match))

        // Panel superior: origen / destino
        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setBackgroundColor(Color.argb(235, 255, 255, 255))
        top.setPadding(dp(8), dp(8), dp(8), dp(8))

        etOrigin = EditText(this)
        etOrigin.hint = "Origen (ciudad)"
        etOrigin.setSingleLine()
        top.addView(etOrigin, LinearLayout.LayoutParams(match, wrap))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        etDest = EditText(this)
        etDest.hint = "Destino (ciudad)"
        etDest.setSingleLine()
        row.addView(etDest, LinearLayout.LayoutParams(0, wrap, 1f))
        val btnTrace = Button(this)
        btnTrace.text = "Trazar"
        btnTrace.setOnClickListener { traceRoute() }
        row.addView(btnTrace, LinearLayout.LayoutParams(wrap, wrap))
        top.addView(row, LinearLayout.LayoutParams(match, wrap))

        root.addView(top, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))

        // Panel inferior: leyenda, estado y botones
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(Color.argb(235, 255, 255, 255))
        bottom.setPadding(dp(8), dp(6), dp(8), dp(6))

        val legend = TextView(this)
        legend.text = legendText()
        legend.textSize = 13f
        bottom.addView(legend, LinearLayout.LayoutParams(match, wrap))

        status = TextView(this)
        status.textSize = 13f
        status.setTextColor(Color.DKGRAY)
        status.text = "Acercá el mapa para ver las rutas"
        bottom.addView(status, LinearLayout.LayoutParams(match, wrap))

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val btnLoc = Button(this)
        btnLoc.text = "Mi ubicación"
        btnLoc.setOnClickListener { onMyLocation() }
        val btnAlerts = Button(this)
        btnAlerts.text = "Avisos"
        btnAlerts.setOnClickListener { checkAlerts() }
        val btnClear = Button(this)
        btnClear.text = "Limpiar"
        btnClear.setOnClickListener { clearRoute() }
        buttons.addView(btnLoc, LinearLayout.LayoutParams(0, wrap, 1f))
        buttons.addView(btnAlerts, LinearLayout.LayoutParams(0, wrap, 1f))
        buttons.addView(btnClear, LinearLayout.LayoutParams(0, wrap, 1f))
        bottom.addView(buttons, LinearLayout.LayoutParams(match, wrap))

        root.addView(bottom, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM))

        setContentView(root)
    }

    private fun legendText(): CharSequence {
        val sb = SpannableStringBuilder()
        fun item(c: Int, t: String) {
            val st = sb.length
            sb.append("■")
            sb.setSpan(ForegroundColorSpan(c), st, st + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(" $t    ")
        }
        item(Color.parseColor("#C62828"), "Nacional")
        item(Color.parseColor("#EF6C00"), "Provincial")
        item(Color.parseColor("#1E88E5"), "Tu recorrido")
        return sb
    }

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    }

    private fun ui(r: () -> Unit) {
        runOnUiThread { r() }
    }

    private fun setStatus(t: String) {
        ui { status.text = t }
    }

    // ---------------------------------------------------------------- Red

    private fun online(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun httpPost(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 100000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("User-Agent", UA)
        try {
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun overpass(q: String): String {
        val body = "data=" + URLEncoder.encode(q, "UTF-8")
        var last: Exception? = null
        val endpoints = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        )
        for (u in endpoints) {
            try {
                return httpPost(u, body)
            } catch (ex: Exception) {
                last = ex
            }
        }
        throw last ?: RuntimeException("overpass")
    }

    // ---------------------------------------------------------------- Rutas

    private fun loadRoutesForView() {
        val z = map.zoomLevelDouble
        if (z < 7.0) {
            setStatus("Acercá el mapa para ver las rutas")
            return
        }
        val national = z < 9.0
        val size = if (national) 4.0 else 1.0
        val bb = map.boundingBox
        val la0 = floor(bb.latSouth / size).toInt()
        val la1 = floor(bb.latNorth / size).toInt()
        val lo0 = floor(bb.lonWest / size).toInt()
        val lo1 = floor(bb.lonEast / size).toInt()
        if ((la1 - la0 + 1) * (lo1 - lo0 + 1) > 16) {
            setStatus("Acercá un poco más para cargar las rutas")
            return
        }
        for (la in la0..la1) {
            for (lo in lo0..lo1) {
                val key = (if (national) "N4" else "A1") + "_" + la + "_" + lo
                if (loaded.containsKey(key) || pending.contains(key)) continue
                pending.add(key)
                val s = la * size
                val w = lo * size
                val n = s + size
                val east = w + size
                roadsExec.execute { fetchCell(key, national, s, w, n, east) }
            }
        }
    }

    private fun fetchCell(key: String, national: Boolean, s: Double, w: Double, n: Double, east: Double) {
        val f = File(File(filesDir, "routes"), "$key.json")
        var text: String? = null
        val stale = !f.exists() ||
            System.currentTimeMillis() - f.lastModified() > 30L * 24 * 3600 * 1000
        if (stale && online()) {
            try {
                val filter = if (national) "^RN" else "^(RN|RP)"
                val q = "[out:json][timeout:90];way[\"highway\"][\"ref\"~\"$filter\"]($s,$w,$n,$east);out geom;"
                text = overpass(q)
                f.writeText(text)
            } catch (ex: Exception) {
                text = null
            }
        }
        if (text == null && f.exists()) {
            text = try {
                f.readText()
            } catch (ex: Exception) {
                null
            }
        }
        val segs: List<Seg>? = if (text != null) {
            try {
                parse(text)
            } catch (ex: Exception) {
                null
            }
        } else null

        runOnUiThread {
            pending.remove(key)
            if (segs == null) {
                status.text = if (online()) "No pude cargar las rutas de esta zona"
                else "Sin conexión: esta zona todavía no está guardada"
            } else {
                addSegments(key, segs)
            }
        }
    }

    private fun parse(text: String): List<Seg> {
        val els = JSONObject(text).getJSONArray("elements")
        val out = ArrayList<Seg>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val g = el.optJSONArray("geometry") ?: continue
            val tags = el.optJSONObject("tags")
            val ref = tags?.optString("ref", "") ?: ""
            val name = tags?.optString("name", "") ?: ""
            val pts = ArrayList<GeoPoint>(g.length())
            for (j in 0 until g.length()) {
                val p = g.getJSONObject(j)
                pts.add(GeoPoint(p.getDouble("lat"), p.getDouble("lon")))
            }
            if (pts.size > 1) out.add(Seg(ref, name, pts))
        }
        return out
    }

    private fun addSegments(key: String, segs: List<Seg>) {
        val list = ArrayList<Polyline>(segs.size)
        for (sg in segs) {
            val p = Polyline(map)
            p.setPoints(sg.pts)
            p.outlinePaint.color = colorFor(sg.ref)
            p.outlinePaint.strokeWidth = dp(if (sg.ref.startsWith("RN")) 4 else 3).toFloat()
            p.title = pretty(sg.ref, sg.name)
            p.setOnClickListener { poly, _, _ ->
                setStatus(poly.title ?: "")
                true
            }
            map.overlays.add(0, p)
            list.add(p)
        }
        loaded[key] = list
        polyCount += list.size
        while (polyCount > 4000 && loaded.size > 1) {
            val k = loaded.keys.first()
            val old = loaded.remove(k)
            if (old != null) {
                map.overlays.removeAll(old.toSet())
                polyCount -= old.size
            }
        }
        map.invalidate()
        status.text = "Rutas cargadas · tocá una ruta para ver su nombre"
    }

    private fun colorFor(ref: String): Int = when {
        ref.startsWith("RN") -> Color.parseColor("#C62828")
        ref.startsWith("RP") -> Color.parseColor("#EF6C00")
        else -> Color.parseColor("#757575")
    }

    private fun pretty(ref: String, name: String): String {
        val r = ref.trim()
        val base = when {
            r.startsWith("RN") -> "Ruta Nacional " + r.removePrefix("RN").trim()
            r.startsWith("RP") -> "Ruta Provincial " + r.removePrefix("RP").trim()
            else -> r
        }
        return if (name.isNotBlank() && name != r) "$base · $name" else base
    }

    // ---------------------------------------------------------------- Recorrido

    private fun geocode(q: String): GeoPoint? {
        val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=ar&q=" +
            URLEncoder.encode(q, "UTF-8")
        val arr = JSONArray(httpGet(url))
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return GeoPoint(o.getString("lat").toDouble(), o.getString("lon").toDouble())
    }

    private fun traceRoute() {
        val a = etOrigin.text.toString().trim()
        val b = etDest.text.toString().trim()
        if (a.isEmpty() || b.isEmpty()) {
            toast("Escribí origen y destino")
            return
        }
        if (!online()) {
            toast("Sin conexión: no se puede calcular un recorrido nuevo")
            return
        }
        setStatus("Calculando recorrido…")
        net.execute {
            try {
                val p1 = geocode(a) ?: throw RuntimeException("No encontré: $a")
                Thread.sleep(1100)
                val p2 = geocode(b) ?: throw RuntimeException("No encontré: $b")
                val url = "https://router.project-osrm.org/route/v1/driving/" +
                    "${p1.longitude},${p1.latitude};${p2.longitude},${p2.latitude}" +
                    "?overview=full&geometries=geojson"
                val osrm = httpGet(url)
                val saved = JSONObject().put("from", a).put("to", b).put("osrm", osrm)
                File(filesDir, "last_route.json").writeText(saved.toString())
                ui { drawRoute(osrm, a, b, true) }
            } catch (ex: Exception) {
                setStatus("No pude trazar el recorrido: " + (ex.message ?: "error"))
            }
        }
    }

    private fun drawRoute(osrm: String, from: String, to: String, zoom: Boolean) {
        val r = JSONObject(osrm).getJSONArray("routes").getJSONObject(0)
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val pts = ArrayList<GeoPoint>(coords.length())
        for (i in 0 until coords.length()) {
            val c = coords.getJSONArray(i)
            pts.add(GeoPoint(c.getDouble(1), c.getDouble(0)))
        }
        routeLine?.let { map.overlays.remove(it) }
        val line = Polyline(map)
        line.setPoints(pts)
        line.outlinePaint.color = Color.parseColor("#1E88E5")
        line.outlinePaint.strokeWidth = dp(7).toFloat()
        val idx = map.overlays.indexOf(locOverlay)
        map.overlays.add(if (idx >= 0) idx else map.overlays.size, line)
        routeLine = line
        routePoints = pts
        map.invalidate()
        if (zoom && pts.size > 1) {
            map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, dp(80))
        }
        val km = r.getDouble("distance") / 1000.0
        val mins = (r.getDouble("duration") / 60.0).toInt()
        status.text = "$from → $to · ${km.toInt()} km · ${mins / 60} h ${mins % 60} min"
    }

    private fun restoreLastRoute() {
        try {
            val f = File(filesDir, "last_route.json")
            if (!f.exists()) return
            val o = JSONObject(f.readText())
            etOrigin.setText(o.getString("from"))
            etDest.setText(o.getString("to"))
            drawRoute(o.getString("osrm"), o.getString("from"), o.getString("to"), false)
        } catch (ex: Exception) {
            // sin recorrido guardado
        }
    }

    private fun clearRoute() {
        routeLine?.let { map.overlays.remove(it) }
        routeLine = null
        routePoints = emptyList()
        File(filesDir, "last_route.json").delete()
        etOrigin.setText("")
        etDest.setText("")
        map.invalidate()
        status.text = "Recorrido borrado"
    }

    // ---------------------------------------------------------------- Ubicación

    private fun hasLoc(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun onMyLocation() {
        if (hasLoc()) {
            locOverlay.enableMyLocation()
            goToMe()
        } else {
            permLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun goToMe() {
        val me: GeoPoint? = locOverlay.myLocation
        if (me != null) {
            map.controller.setZoom(12.0)
            map.controller.animateTo(me)
        } else {
            toast("Buscando tu ubicación…")
            locOverlay.runOnFirstFix(Runnable {
                runOnUiThread {
                    val m: GeoPoint? = locOverlay.myLocation
                    if (m != null) {
                        map.controller.setZoom(12.0)
                        map.controller.animateTo(m)
                    }
                }
            })
        }
    }

    // ---------------------------------------------------------------- Avisos

    private fun checkAlerts() {
        if (!online()) {
            showAlertDialog("Sin conexión. Los avisos necesitan internet.")
            return
        }
        val pts = ArrayList<Pair<String, GeoPoint>>()
        if (routePoints.size > 1) {
            val labels = listOf("Origen", "25 % del camino", "50 % del camino", "75 % del camino", "Destino")
            val fr = listOf(0.0, 0.25, 0.5, 0.75, 1.0)
            for (k in fr.indices) {
                pts.add(labels[k] to routePoints[((routePoints.size - 1) * fr[k]).toInt()])
            }
        } else {
            val me: GeoPoint? = locOverlay.myLocation
            if (me != null) {
                pts.add("Tu ubicación" to GeoPoint(me.latitude, me.longitude))
            } else {
                val c = map.mapCenter
                pts.add("Centro del mapa" to GeoPoint(c.latitude, c.longitude))
            }
        }
        setStatus("Consultando pronóstico…")
        net.execute {
            val sb = StringBuilder()
            for ((label, p) in pts) {
                val line = try {
                    forecastLine(p)
                } catch (ex: Exception) {
                    "sin datos"
                }
                sb.append("• ").append(label).append(": ").append(line).append("\n")
            }
            ui {
                status.text = "Avisos listos"
                showAlertDialog(sb.toString().trim())
            }
        }
    }

    private fun forecastLine(p: GeoPoint): String {
        val lat = String.format(Locale.US, "%.3f", p.latitude)
        val lon = String.format(Locale.US, "%.3f", p.longitude)
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&hourly=precipitation,wind_gusts_10m&forecast_hours=24&timezone=auto"
        val h = JSONObject(httpGet(url)).getJSONObject("hourly")
        val pr = h.getJSONArray("precipitation")
        val wg = h.getJSONArray("wind_gusts_10m")
        var total = 0.0
        var maxH = 0.0
        var gust = 0.0
        for (i in 0 until pr.length()) {
            val v = pr.optDouble(i, 0.0)
            if (!v.isNaN()) {
                total += v
                if (v > maxH) maxH = v
            }
        }
        for (i in 0 until wg.length()) {
            val v = wg.optDouble(i, 0.0)
            if (!v.isNaN() && v > gust) gust = v
        }
        val w = ArrayList<String>()
        if (total >= 50 || maxH >= 20) {
            w.add("lluvia muy intensa (${total.toInt()} mm en 24 h), posible anegamiento")
        } else if (maxH >= 8 || total >= 25) {
            w.add("lluvia fuerte (${total.toInt()} mm en 24 h)")
        }
        if (gust >= 90) {
            w.add("viento muy fuerte (ráfagas de ${gust.toInt()} km/h)")
        } else if (gust >= 60) {
            w.add("viento fuerte (ráfagas de ${gust.toInt()} km/h)")
        }
        return if (w.isEmpty()) "sin riesgos destacados" else w.joinToString("; ")
    }

    private fun showAlertDialog(body: String) {
        if (isFinishing) return
        val msg = body + "\n\nEs una estimación según el pronóstico de las próximas 24 h, " +
            "no una alerta oficial. Para alertas oficiales y cortes de ruta usá los botones."
        AlertDialog.Builder(this)
            .setTitle("Avisos en tu ruta")
            .setMessage(msg)
            .setPositiveButton("Alertas SMN") { _, _ -> openUrl("https://www.smn.gob.ar/alertas") }
            .setNeutralButton("Estado de rutas") { _, _ ->
                openUrl("https://www.argentina.gob.ar/transporte/vialidad-nacional")
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun openUrl(u: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        } catch (ex: Exception) {
            toast("No pude abrir el navegador")
        }
    }

    // ---------------------------------------------------------------- Ciclo de vida

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLoc()) locOverlay.enableMyLocation()
    }

    override fun onPause() {
        super.onPause()
        locOverlay.disableMyLocation()
        map.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        roadsExec.shutdownNow()
        net.shutdownNow()
        map.onDetach()
    }
}
